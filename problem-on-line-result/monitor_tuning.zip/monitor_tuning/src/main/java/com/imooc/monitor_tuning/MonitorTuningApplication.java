package com.imooc.monitor_tuning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonitorTuningApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonitorTuningApplication.class, args);
	}

}
