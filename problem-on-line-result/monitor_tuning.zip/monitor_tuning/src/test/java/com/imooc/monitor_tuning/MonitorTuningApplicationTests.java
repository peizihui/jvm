package com.imooc.monitor_tuning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitorTuningApplicationTests {

	@Test
	void contextLoads() {
	}

}
