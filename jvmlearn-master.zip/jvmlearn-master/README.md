# java基础知识学习

#The World Of Concurrent 线程基础

#Chapter1:
    MultiThreadLong 原子性概念理解</br>
#Chapter2:
    NoVisibility：volatile声明变量</br>
    VolatileTask：volatile深入</br>
    PriorityDemo：线程优先级</br>
    BadSuspend：suspend挂起线程</br>
    DaemonDemo：守护线程</br>
    InterruptThread：线程中断</br>
    JoinMain：线程的join方法</br>
    SimpleWN：等待wait和通知notify</br>
    SleepThread：线程休眠</br>
    ThreadGroupName：线程组</br>
    AccountingSync：线程安全与synchonized</br>
    AccountingSync2：线程安全与synchonized</br>
    AccountingSyncBad：synchonized的错误使用</br>
    AccountingVol：同步会出现的问题</br>
    ArrayListMultiThread：并发下的ArrayList</br>
#Chapter3：
    ReenterLock：重入锁</br>
    ReentrantLockCondition：重入锁Condition</br>
    FairLock：公平锁</br>
    IntLock：死锁</br>
#Chapter4：
    ScheduledExecutorServiceDemo 线程定时器</br>
    ThreadPoolDemo newFixedThreadPool()为例，简单的展示线程池的使用</br>
    RejectThreadPoolDemo 自定义线程和拒绝策略</br>