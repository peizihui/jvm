package com.bjut.JVMTest;

public class intTest01 {
    public static void main(String args[]) {
        int a = 1;
        Integer b = 1;
        System.out.println(a == b);
        System.out.println(int.class);
        System.out.println(Integer.class);
    }
}
 