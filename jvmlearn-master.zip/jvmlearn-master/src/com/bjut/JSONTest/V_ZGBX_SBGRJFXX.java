package com.bjut.JSONTest;

public class V_ZGBX_SBGRJFXX {

    private String AAA115;
    private String AAA027;
    private String AAB999;
    private String AAC049;
    private String AAC147;
    private String AAB004;
    private String AAZ200;
    private String AAC001;
    private String AAA042;
    private String AAE003;
    private String AAA041;
    private String AAE036;
    private String AAE002;
    private String AAE140;
    private String AAE150;
    private String AAE083;
    private String AAE082;
    private String AAE180;
    private String AAE081;
    private String AAE080;

    public void setAAA115(String AAA115) {
        this.AAA115 = AAA115;
    }

    public String getAAA115() {
        return AAA115;
    }

    public void setAAA027(String AAA027) {
        this.AAA027 = AAA027;
    }

    public String getAAA027() {
        return AAA027;
    }

    public void setAAB999(String AAB999) {
        this.AAB999 = AAB999;
    }

    public String getAAB999() {
        return AAB999;
    }

    public void setAAC049(String AAC049) {
        this.AAC049 = AAC049;
    }

    public String getAAC049() {
        return AAC049;
    }

    public void setAAC147(String AAC147) {
        this.AAC147 = AAC147;
    }

    public String getAAC147() {
        return AAC147;
    }

    public void setAAB004(String AAB004) {
        this.AAB004 = AAB004;
    }

    public String getAAB004() {
        return AAB004;
    }

    public void setAAZ200(String AAZ200) {
        this.AAZ200 = AAZ200;
    }

    public String getAAZ200() {
        return AAZ200;
    }

    public void setAAC001(String AAC001) {
        this.AAC001 = AAC001;
    }

    public String getAAC001() {
        return AAC001;
    }

    public void setAAA042(String AAA042) {
        this.AAA042 = AAA042;
    }

    public String getAAA042() {
        return AAA042;
    }

    public void setAAE003(String AAE003) {
        this.AAE003 = AAE003;
    }

    public String getAAE003() {
        return AAE003;
    }

    public void setAAA041(String AAA041) {
        this.AAA041 = AAA041;
    }

    public String getAAA041() {
        return AAA041;
    }

    public void setAAE036(String AAE036) {
        this.AAE036 = AAE036;
    }

    public String getAAE036() {
        return AAE036;
    }

    public void setAAE002(String AAE002) {
        this.AAE002 = AAE002;
    }

    public String getAAE002() {
        return AAE002;
    }

    public void setAAE140(String AAE140) {
        this.AAE140 = AAE140;
    }

    public String getAAE140() {
        return AAE140;
    }

    public void setAAE150(String AAE150) {
        this.AAE150 = AAE150;
    }

    public String getAAE150() {
        return AAE150;
    }

    public void setAAE083(String AAE083) {
        this.AAE083 = AAE083;
    }

    public String getAAE083() {
        return AAE083;
    }

    public void setAAE082(String AAE082) {
        this.AAE082 = AAE082;
    }

    public String getAAE082() {
        return AAE082;
    }

    public void setAAE180(String AAE180) {
        this.AAE180 = AAE180;
    }

    public String getAAE180() {
        return AAE180;
    }

    public void setAAE081(String AAE081) {
        this.AAE081 = AAE081;
    }

    public String getAAE081() {
        return AAE081;
    }

    public void setAAE080(String AAE080) {
        this.AAE080 = AAE080;
    }

    public String getAAE080() {
        return AAE080;
    }

}