package com.bjut.JSONTest;

/*
 *
 *   json -> entity
 * */
public class V_ZGBX_SBGRJBXXa {
    private String BAE039;
    private String AAC999;

    public String getBAE039() {
        return BAE039;
    }

    public void setBAE039(String BAE039) {
        this.BAE039 = BAE039;
    }

    public String getAAC999() {
        return AAC999;
    }

    public void setAAC999(String AAC999) {
        this.AAC999 = AAC999;
    }
}
