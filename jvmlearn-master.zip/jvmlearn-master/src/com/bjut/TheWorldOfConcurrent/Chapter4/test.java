package com.bjut.TheWorldOfConcurrent.Chapter4;

public class test implements Runnable{

    @Override
    public void run() {
        System.out.println("1");
    }
}
